function calc() {
   //TODO: 
}