function showText() {
    let link = document.getElementsByTagName('A')[0];
    let text = document.querySelector('span');
    link.style.display = 'none';
    text.style.display = 'inline';

}