function stopwatch() {
    // TODO:
}