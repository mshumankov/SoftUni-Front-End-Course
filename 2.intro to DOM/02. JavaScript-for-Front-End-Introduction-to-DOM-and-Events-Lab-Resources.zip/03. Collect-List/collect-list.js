function extractText() {
    //TODO:
}