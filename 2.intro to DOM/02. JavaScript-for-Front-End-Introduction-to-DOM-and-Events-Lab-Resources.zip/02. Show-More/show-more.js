function showText() {
    //TODO:
}